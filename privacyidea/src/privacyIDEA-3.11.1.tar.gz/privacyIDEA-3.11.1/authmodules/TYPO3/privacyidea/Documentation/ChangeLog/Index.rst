﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


.. _changelog:

ChangeLog
=========

2016-06-10 0.2.0
----------------

Add the possibility to distinguish between admin users and normal users
in the BE module.

2015-05-11 0.1.4
----------------

Improving the documentation.


2015-05-11 0.1.0
-----------------

Initial upload of the extension.

