'''
The useridresolver is responsible for getting userids for loginnames and vice versa.

This base module contains the base class UserIdResolver.UserIdResolver and also the
community class PasswdIdResolver.IdResolver, that is inherited from the base class.
'''
