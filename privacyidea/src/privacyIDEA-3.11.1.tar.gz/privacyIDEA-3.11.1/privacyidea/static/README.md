This is the Web Client for the privacyIDEA authentication service.

The Web Client acts as a Single Page Application that communicates with the
privacyIDEA backend service. You could as well install and run the Web Client
on another exposed Webserver, while shielding the orginial privacyIDEA
backend service in a more protected network segment.

The privacyIDEA Web Client is licensed under the AGPLv3.

(c) 2015 Cornelius Kölbel <cornelius.koelbel@netknights.it>


  This code is free software; you can redistribute it and/or
  modify it under the terms of the GNU AFFERO GENERAL PUBLIC LICENSE
  License as published by the Free Software Foundation; either
  version 3 of the License, or any later version.

  This code is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU AFFERO GENERAL PUBLIC LICENSE for more details.

  You should have received a copy of the GNU Affero General Public
  License along with this program.  If not, see <http://www.gnu.org/licenses/>.
