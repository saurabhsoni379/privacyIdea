"""merge SMS options and privacyIDEA nodes

Revision ID: 140ba0ca4f07
Revises: ('e360c56bcf8c', '631ec59e1ca6')
Create Date: 2020-06-26 12:40:39.663531

"""

# revision identifiers, used by Alembic.
revision = '140ba0ca4f07'
down_revision = ('e360c56bcf8c', '631ec59e1ca6')

from alembic import op
import sqlalchemy as sa


def upgrade():
    pass


def downgrade():
    pass
